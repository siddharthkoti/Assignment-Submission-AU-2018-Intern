package main;

public class node {
	node(int k,int v)
	{
		key=k;
		value=v;
	}
	
	
	node()
	{}
	
	int key;
	int value;
	
	public int getkey()
	{
		return key;
	}
	
	public int getvalue()
	{
		return value;
	}
}
