package soapAssignment;

import javax.jws.WebMethod;
import javax.jws.WebService;



@WebService
public interface soapInterface {
	
	@WebMethod
	String add(String name);
	
	@WebMethod
	String delete(String name);
	
	@WebMethod
	String update(String n1, String n2);
	
	@WebMethod
	public String get(int n);
}
